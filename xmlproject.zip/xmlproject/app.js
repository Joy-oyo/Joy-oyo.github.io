const base_url = "https://ochre.lib.uchicago.edu/ochre?uuid=";

function loadOchreData(uuid, containerSelector) {
    //url
    const url = base_url + uuid;

    fetch(url)
        .then((response) => response.text())
        .then((xmlString) => {
            //parsexml
            const parser = new DOMParser();
            const xml = parser.parseFromString(xmlString, "application/xml");

            //extract the title
            let title;
                  // Case 1: XML structure for "RS 15.001"
            const spatialUnitTitle = xml.querySelector("spatialUnit > identification > label > content > string")?.textContent;
            if (spatialUnitTitle) {
                    title = spatialUnitTitle;
                }

            const labelText = xml.querySelector("resource > identification > label")?.textContent;
            if (labelText) {
                    title = labelText;
                }

            //extrac properties
            const
            properties = extractProperties(xml);

            //etract preview image URL
            const previewImage = xml.querySelector("previewImage")?.getAttribute("src") || null;


            //build
            let html = `<h1>${title}<h1>`;
            // https://ochre.lib.uchicago.edu/ochre?uuid=50f7b9a5-329a-49ab-85e2-f8fb4ee6e867&load
            if (previewImage) {
                html += `<img src="${previewImage}" alt="${title}" class="img-fluid mb-4">`;
            }
            if (properties.length > 0) {
                html += "<h3>Properties:</h3><ul>";
                html += "<table>";
                properties.forEach((prop) => {
                        html += `<tr><td><strong>${prop.name}</strong></td><td>${prop.value}</td></tr>`;
                });
                html += "</ul>";
                html += "</table>";
            } else {
                html += "<p>No properties available.</p>";
            }

            // Display the HTML in the container
            document.querySelector(containerSelector).innerHTML = html;
        })
        .catch((error) => {
            console.error("Error fetching OCHRE data:", error);
            document.querySelector(containerSelector).innerHTML = "<p>Error loading data.</p>";
        });
}

function extractProperties(xml) {
    const observations = xml.querySelectorAll("observation");
    let properties = [];
  
    observations.forEach((observation) => {
      const observationProperties = observation.querySelectorAll("properties > property");
      observationProperties.forEach((property) => {
        const label = property.querySelector("label > content > string")?.textContent;
        const value = property.querySelector("value")?.textContent.trim();
  
        if (label && value) {
          properties.push({
            name: label,
            value: value,
          });
        }
      });
    });
  
    return properties;
  }